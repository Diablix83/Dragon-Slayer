<?php

	class UsersController extends Controller {
		public $modelName = 'UsersModel';


		// pour tester:
		// askdb.php?controller=users&task=askCreateUser&email=alex83.derai%40gmail.com&pseudo=diablix&password=555555&confirmPassword=555555
		// askdb.php?controller=users&task=validateCreateUser&unique_id=219c188ca9ad6f74fe77458c7a432c7879a6a563
		public function askCreateUser(){
			if(isset($_GET['email']) && isset($_GET['pseudo']) && isset($_GET['password']) && isset($_GET['confirmPassword'])){
				$email = $_GET['email'];
				$pseudo = $_GET['pseudo'];
				$password = $_GET['password'];
				$confirmPassword = $_GET['confirmPassword'];
				
				if($password == $confirmPassword){
					
					$date_creation = date('Y-m-d H:i:s');
					
					$uuid = uniqid().$email.$pseudo;
					$uuidHash = hash('ripemd160', $uuid);
					
					$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 13]);
				
					$userData = ['email' => $email, 'pseudo' => $pseudo, 'password' => $hash, 'activated' => 0, 'date_creation' => $date_creation, 'uuid' => $uuidHash];
					$request = $this->model->save($userData);
				    
				    
				    
				    // Preparation pour mail
				    $encoding = "utf-8";
	
				    // En-tête du mail
				    $header = "MIME-Version: 1.0 \r\n";
				    $header .= "Content-type: text/html; charset=".$encoding." \r\n";
				    
				    // Sujet du mail
					$subject ='Mail de confirmation pour le jeu Dragon-Slayer';
	
					// Message du mail
					$message = '
						<html>
							<head>
								<title>Calendrier des anniversaires pour Août</title>
							</head>
							<body>
								<p>Ceci est un mail automatique, merci de ne pas y répondre.</p>
								<p>Félicitation, vous venez de vous inscrire au Jeu Dragon-Slayer !</p>
								<p>Pour rappel vous vous êtes inscrit avec le pseudo : '.$pseudo.'.</p>
								<p>Pour valider votre inscription, cliquez sur le lien ci-dessous, ou alors copier le dans la barre d\'adresse de votre navigateur :</p>
								<p><a href="https://dragon-slayer-diablix83.c9users.io/Dragon-Slayer-master/php/askdb.php?controller=users&task=validateCreateUser&unique_id='.$uuidHash.'">https://dragon-slayer-diablix83.c9users.io/Dragon-Slayer-master/php/askdb.php?controller=users&task=validateCreateUser&unique_id='.$uuidHash.'</a></p>
								<p>A bientôt sur le Jeu !</p>
							</body>
						</html>
								';
	
				    // Envoyer le mail
				    var_dump($email);
				    echo '<br><br>';
				    var_dump($message);
					//mail(urlencode($email), $subject, $message, $header);
				}
			}
			else header('location:index.php?controller=users&task=error&message='.$messageHash);
		}
		
		public function validateCreateUser(){
			$unique_id = $_GET['unique_id'];
			$requestVerif = $this->model->findByUniqueId($unique_id);
			$requestActivate = $this->model->activateUser($unique_id);
		}
		
		public function userConnexionTest(){
			$email = 'cequetuveux@connard.fr';
			$password = '555555';
			$userData = $this->model->findByEmail($email);
			
			//var_dump($verifPassword);
			if(password_verify($password, $userData['password'])){ echo 'OK'; /* return true */ }
			else{ echo 'ERREUR'; /* return false */ }
		}
		
		public function userConnexion(){
			$email = $_GET['email'];
			$password = $_GET['password'];
			$userData = $this->model->findByEmail($email);
			
			//var_dump($verifPassword);
			
			if(password_verify($password, $userData['password'])){
				echo 'true';
			}
			else{
				echo 'false';
			}
		}
		
	}
?>
