<?php

	class PlayersController extends Controller {
		public $modelName = 'CharactersModel';


	}
	
?>
