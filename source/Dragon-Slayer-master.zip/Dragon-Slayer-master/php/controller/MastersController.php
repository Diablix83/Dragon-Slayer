<?php

	class MastersController extends Controller {
		public $modelName = 'ItemsModel';



		public function allItems(){
			$donnees = $this->model->all();

			$json = json_encode($donnees);
			echo $json;
		}
		
		
		
		public function getOptimalCost(){
			$timeTarget = 0.3;
		    $cost = 9;
		    do {
		        $cost++;
		        $start = microtime(true);
		        password_hash("test", PASSWORD_BCRYPT, ["cost" => $cost]);
		        $end = microtime(true);
		    } while (($end - $start) < $timeTarget);
		    
		    echo $cost;
		    //return $cost;
		}
		
		public function readPassword(){
			$email = 'jeje@caca.com';
			
			$usersModel = new UsersModel();
			$verifPassword = $usersModel->verifPasswordByEmail($email);
			
			var_dump($verifPassword);
		}
	}
	
?>
