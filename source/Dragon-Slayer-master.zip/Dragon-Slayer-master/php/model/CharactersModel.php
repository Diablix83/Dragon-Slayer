<?php

	class CharactersModel extends Model{

		protected $table = 'project001_characters';
	}
?>
