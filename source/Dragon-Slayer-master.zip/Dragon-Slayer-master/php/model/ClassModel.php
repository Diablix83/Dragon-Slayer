<?php

	class ClassModel extends Model{

		protected $table = 'project001_class';
	}
?>
