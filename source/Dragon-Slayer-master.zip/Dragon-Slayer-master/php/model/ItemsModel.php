<?php

	class ItemsModel extends Model{

		protected $table = 'project001_items';
	}
?>
