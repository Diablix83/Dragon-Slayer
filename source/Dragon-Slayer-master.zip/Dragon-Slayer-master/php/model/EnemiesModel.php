<?php

	class EnemiesModel extends Model{

		protected $table = 'project001_enemies';
	}
?>
