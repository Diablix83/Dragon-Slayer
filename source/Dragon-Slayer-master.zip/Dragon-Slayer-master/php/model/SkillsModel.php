<?php

	class SkillsModel extends Model{

		protected $table = 'project001_skills';
	}
?>
